#!/usr/bin/env python
# coding: utf-8

# ### Objective: Uber Data Analysis to Predict the Price Using Linear Regression Algorithm ###

# In[1]:


import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import itertools
import gc
import os
import sys
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


cab_data=pd.read_csv(r"D:\cab_rides.csv")


# In[5]:


weather_data=pd.read_csv(r"D:\weather.csv")


# In[6]:


cab_data.head()


# In[7]:


cab_data.columns


# In[8]:


cab_data.shape


# In[9]:


cab_data.describe()


# In[10]:


weather_data.head()


# In[11]:


weather_data.columns


# In[12]:


weather_data.shape


# In[13]:


weather_data.describe()


# In[15]:


import datetime
cab_data['datetime']=pd.to_datetime(cab_data['time_stamp'])


# In[16]:


cab_data.head()


# In[17]:


a=pd.concat([cab_data,weather_data])


# In[18]:


a.head()


# In[20]:


a['day']=a.datetime.dt.day


# In[21]:


a.head()


# In[22]:


a['hour']=a.datetime.dt.hour


# In[23]:


a.head()


# In[24]:


a.fillna(0,inplace=True)


# In[25]:


a.head()


# In[26]:


a.columns


# In[27]:


a.groupby('cab_type').count()


# In[28]:


a.groupby('cab_type').count().plot.bar()


# In[29]:


a['price'].value_counts().plot(kind='bar',figsize=(100,50),color='blue')


# In[30]:


a['hour'].value_counts().plot(kind='bar',figsize=(10,5),color='blue')


# In[31]:


x=a['hour']
y=a['price']
plt.plot(x,y)
plt.show()


# In[32]:


x=a['rain']
y=a['price']
plt.plot(x,y)
plt.show()


# In[33]:


x1=a[['distance','temp','pressure','humidity','wind','rain','day','hour','surge_multiplier','clouds']] ## Training data ##
y1=a['price'] ## Label data ##


# In[34]:


## Using Skicit-learn to split data into training and testing sets ##
from sklearn.model_selection import train_test_split
## split the data into training and testing sets ##
x_train,y_train,x_test,y_test=train_test_split(x1,y1,test_size=0.25,random_state=42)


# In[35]:


linear=LinearRegression()
linear.fit(x_train,x_test)

## Train your model using x_train and x_test data this helps in model to learn ##


# In[36]:


predictions=linear.predict(y_train) ## predictions for your model ##
predictions


# In[37]:


df=pd.DataFrame({'Actual':y_test,'Predicted':predictions})
df


# In[38]:


df1=df.head(25)
df1.plot(kind='bar',figsize=(26,10))
plt.grid(which='major',linestyle='-',linewidth='0.5',color='green')
plt.grid(which='major',linestyle=':',linewidth='0.5',color='black')
plt.show()

## Graph shows Predicted and Actual Values whereever Actual and Predicted values having slight difference indicates that
matches/fit our model. Whereever Actual and Predicted Valyes having More difference indicates that doesnot matches
fit(our, model, ##)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




